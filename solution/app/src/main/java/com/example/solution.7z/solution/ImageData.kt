package com.example.solution

class ImageData(var theText:String,var image_card: Int
) {


}